package com.gyungdal.homenews.Card;

import android.support.v7.app.AppCompatActivity;

import com.gyungdal.homenews.R;
/**
 *
 * Created by GyungDal on 2015-11-15.
 */
public class Description extends AppCompatActivity {
    public int Image_Select(int What, int Value, boolean Check) {
        if (!Check)
            return R.drawable.unknow;
        else {
            switch (What) {
                case R.string.Temp:
                    if (Value < 5 || Value > 35) return R.drawable.danger;
                    else if (Value < 13 || Value > 24) return R.drawable.unsafe;
                    else return R.drawable.safe;
                case R.string.Humi:
                    if (Value < 30 || Value > 80) return R.drawable.danger;
                    else if (Value < 40 || Value > 70) return R.drawable.unsafe;
                    else return R.drawable.safe;
                case R.string.Gas:
                    if (Value > 10000) return R.drawable.danger;
                    else if (Value > 5000) return R.drawable.unsafe;
                    else return R.drawable.safe;
                case R.string.Dust:
                    if (Value > 700) return R.drawable.danger;
                    else if (Value > 500) return R.drawable.unsafe;
                    else return R.drawable.safe;
                default:
                    return R.drawable.unknow;
            }
        }
    }
}
