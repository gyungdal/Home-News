package com.gyungdal.homenews.Network;

import com.android.volley.Response;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.navercorp.volleyextensions.volleyer.Volleyer;


@JsonIgnoreProperties(ignoreUnknown = true)
public class Read {
    @JsonProperty("Temp")
    private static String Temp;
    @JsonProperty("Humi")
    private static String Humi;
    @JsonProperty("Gas")
    private static String Gas;
    @JsonProperty("Dust")
    private static String Dust;
    Check check;
    private static String Url = "192.168.0.80";

    public Read(Check check){
        this.check = check;
    }
    public void seturl(String Url){
        this.Url = Url;
    }
    public String geturl(){return this.Url;}
    public boolean Data_Read()
    {
        if(check.isNetConnect(Url)) {
            Volleyer.volleyer().get(Url)
                    .withTargetClass(Read.class)
                    .withListener(listener1)
                    .execute();
            return true;
        }else
            return false;
    }

    private Response.Listener<Read> listener1 = new Response.Listener<Read>()
    {
        @Override
        public void onResponse(Read item)
        {
        }
    };

}