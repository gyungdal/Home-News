package com.gyungdal.homenews.Event;

import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;

import com.gyungdal.homenews.Network.Check;
import com.gyungdal.homenews.Network.Read;
import com.gyungdal.homenews.R;

import java.util.concurrent.Delayed;

/**
 * Created by GyungDal on 2015-11-23.
 */
public class Floating implements View.OnClickListener {
    private Check Net;
    private Read read;
    public Floating(Check Net,Read read){
        this.Net = Net;
        this.read = read;
    }
    @Override
    public void onClick(View view) {
        if (Net.isNetwork() == true){
            Snackbar.make(view, R.string.Sync, Snackbar.LENGTH_SHORT)
                    .setAction("Action", null).show();
            if(read.Data_Read())
                Snackbar.make(view, R.string.Url_Success, Snackbar.LENGTH_SHORT)
                        .setAction("Action", null).show();
            else
                Snackbar.make(view, R.string.Url_Error, Snackbar.LENGTH_SHORT)
                        .setAction("Action", null).show();
        }
        else{
            Snackbar.make(view,R.string.Sync_Fail,Snackbar.LENGTH_SHORT)
                    .setAction("Action", null).show();
        }
    }

}
