package com.gyungdal.homenews.Recycle;

import android.support.v7.app.AppCompatActivity;

import com.gyungdal.homenews.MainActivity;

/**
 * Created by GyungDal on 2015-11-12.
 */
public class Recycle{
    private int image;
    private String title;
    private String Des;
    private final int Num;

    public int getImage(){return this.image;}
    public String getTitle(){ return this.title; }
    public String getDes(){ return this.Des; }
    public int getNum(){return this.Num;}

    public Recycle(int image, String title, String Des, int Num){
        this.image= image;
        this.title= title;
        this.Des = Des;
        this.Num = Num;
    }
}
