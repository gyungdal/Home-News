package com.gyungdal.homenews;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.transition.Slide;
import android.transition.TransitionInflater;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

import com.gyungdal.homenews.Card.Description;
import com.gyungdal.homenews.Event.Floating;
import com.gyungdal.homenews.Network.Check;
import com.gyungdal.homenews.Network.Read;
import com.gyungdal.homenews.Recycle.Recycle;
import com.gyungdal.homenews.Recycle.RecyclerAdapter;

public class MainActivity extends AppCompatActivity {
    private int Temp;
    private int Dust;
    private int Gas;
    private int Humi;
    public SharedPreferences sharedPref ;
    private List<Recycle> items;
    private Recycle[] item;

    public static Check Net;
    private Description Select;
    private RecyclerView recyclerView;
    public static Read Read;
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "Create main activity");
        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        Net = new Check(getApplicationContext());
        Read = new Read(Net);
        items=new ArrayList<>();
        item =new Recycle[4];
        Select = new Description();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        recyclerView=(RecyclerView)findViewById(R.id.recyclerview);

        if(!Net.isNetwork())
            Snackbar.make(recyclerView, R.string.Sync_Fail, Snackbar.LENGTH_SHORT)
                    .setAction("Action", null).show();
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new Floating(Net,Read));

        Initialize();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if(id==R.id.action_settings){
            Url();
            //Toast.makeText(getApplicationContext(), R.string.Preparing, Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private void Initialize(){

        //LinearLayout Init
        GridLayoutManager gridManager =  new GridLayoutManager(getApplicationContext(),2);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(gridManager);

        // Recycle View Init
        item[0]=new Recycle(Select.Image_Select(R.string.Temp, Temp, Net.isNetConnect(Read.geturl())),
                getString(R.string.Temp), String.valueOf(Temp), 0);

        item[1]=new Recycle(Select.Image_Select(R.string.Dust, Humi, Net.isNetConnect(Read.geturl()))
                , getString(R.string.Humi),String.valueOf(Humi), 1);

        item[2]=new Recycle(Select.Image_Select(R.string.Gas,Gas, Net.isNetConnect(Read.geturl())),
                getString(R.string.Gas),String.valueOf(Gas), 2);

        item[3]=new Recycle(Select.Image_Select(R.string.Dust,Dust, Net.isNetConnect(Read.geturl())),
                getString(R.string.Dust),String.valueOf(Dust), 3);

        //List Add to Recycle
        for(int i=0;i<4;i++) items.add(item[i]);

        //Recycle View using Adapter

        recyclerView.setAdapter(new RecyclerAdapter(getApplicationContext(),items,R.layout.activity_main));
    }

    private void Url() {

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle(R.string.Url_Title);
        alert.setMessage(R.string.Url_Des);

        // Set an EditText view to get user input
        final EditText Url = new EditText(this);
        Url.setHint(getString(R.string.Url_Hint) + Read.geturl());
        /*final EditText password = new EditText(this);
        password.setHint(PASSWORD_HINT);*/
        LinearLayout layout = new LinearLayout(getApplicationContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(Url);
        //layout.addView(password);
        alert.setView(layout);

        alert.setPositiveButton(getString(R.string.Url_Ok), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                try {
                    Read.seturl(Url.getText().toString());
                } catch (Exception e) {
                    Log.e(TAG, "URL input Error");
                }
            }
        });

        alert.setNegativeButton(getString(R.string.Url_Cancel), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // Canceled.
            }
        });

        alert.show();
    }
}

