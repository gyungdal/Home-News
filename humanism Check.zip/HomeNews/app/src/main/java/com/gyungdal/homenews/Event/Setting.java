package com.gyungdal.homenews.Event;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by GyungDal on 2015-11-23.
 */
public class Setting extends AppCompatActivity{
    private static final String TAG = "Setting Event";
}
